from . import HypeCycle
import numpy as np
import matplotlib.pyplot as plt